# Changelog

## 0.2.0 (2023-03-31)

#### New Features

* add moveup() and __sub__() methods
#### Others

* update readme
* change __sub__ docstring


## v0.1.0 (2023-03-31)

#### New Features

* add touch()
#### Others

* build v0.1.0
* update changelog
* update .gitignore


## v0.0.0 (2023-03-28)

#### New Features

* add copy method to Pathier class.
#### Fixes

* wrong string in __all__.
#### Others

* build v0.0.0
* add to readme.
* add test for copy function.