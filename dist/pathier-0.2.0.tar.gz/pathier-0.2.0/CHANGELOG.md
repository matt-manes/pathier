# Changelog

## 0.1.0 (2023-03-31)

#### New Features

* add touch()
#### Others

* update .gitignore


## v0.0.0 (2023-03-28)

#### New Features

* add copy method to Pathier class.
#### Fixes

* wrong string in __all__.
#### Others

* build v0.0.0
* add to readme.
* add test for copy function.